# VaynerMedia Utility Functions
A library to help create python pipelines for processing Tracer Data

### Installation
```
pip install veetility
```

### Get started
